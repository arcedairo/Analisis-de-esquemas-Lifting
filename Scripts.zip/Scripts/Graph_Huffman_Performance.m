lvl=7;

%imagenes = ["CT_Torax_1.dcm", "CT_Prostata_1.dcm", "CT_Pediatrica_1.dcm", "CT_Cerebral_1.dcm", "CT_Cerebral_2.dcm", "CT_Abdomen_1.dcm", "CT_Abdomen_2.dcm", "CT_Abdomen_3.dcm","CT_Abdomen_4.dcm","CT_Abdomen_5.dcm"];
%imagenes = ["MRI_Seno_1.dcm", "MRI_Rinon_1.dcm", "MRI_Pelvis_1.dcm", "MRI_Pelvis_2.dcm", "MRI_Pancreas_1.dcm", "MRI_Cerebral_1.dcm", "MRI_Cerebral_2.dcm", "MRI_Cerebral_3.dcm","MRI_Abdomen_1.dcm","MRI_Abdomen_2.dcm"];
imagenes = ["US_ECHO_1.dcm", "US_ECHO_2.dcm", "US_ECHO_3.dcm", "US_ECHO_4.dcm", "US_ECHO_5.dcm", "US_ECHO_6.dcm", "US_ECHO_7.dcm", "US_ECHO_8.dcm","US_ECHO_9.dcm","US_ECHO_10.dcm"];
%wavelet_madre = ["db1", "db2", "db3", "db4", "db5", "db6", "db7", "db8"];
%wavelet_madre = ["db1","db2","sym2","sym4","coif1","bior2.2","bior2.4"];
%wavelet_madre = ["db1", "db2", "sym2", "sym4", "coif1", "bior2.2", "bior2.4", "bior3.3"];
%wavelet_madre = ["sym2", "sym3", "sym4", "sym5", "sym6", "sym7", "sym8"];
%wavelet_madre = ["coif1", "coif2"];
%wavelet_madre = ["db2","db3","sym4","sym5","coif1","bior3.1","bior3.3"];
%wavelet_madre = ["db2","db3","sym4","sym5","coif1","bior3.1","bior3.3"];
%wavelet_madre = ["db1","db2","sym2","sym4","coif1","bior2.2","bior2.4","bior3.3"];
wavelet_madre = ["bior1.1","bior1.3","bior1.5","bior2.2","bior2.4","bior2.6","bior2.8","bior3.1","bior3.3","bior3.5","bior3.7","bior3.9","bior4.4","bior5.5","bior6.8"];
%archivo_eficiencia = ["eficiencia_db1_CT.xls","eficiencia_db2_CT.xls", "eficiencia_db3_CT.xls", "eficiencia_db4_CT.xls", "eficiencia_db_US.xls", "eficiencia_bior2.2_US.xls", "eficiencia_bior2.4_US.xls"];
%archivo_ratio = ["compression_ratio_db1.xls","compression_ratio_db2.xls", "compression_ratio_db3.xls", "compression_ratio_db4.xls", "compression_ratio_db5.xls", "compression_ratio_db6.xls", "compression_ratio_db7.xls", "compression_ratio_db8.xls"];
%archivo_ratio = ["compression_ratio_db1_CT.xls", "compression_ratio_db2_CT.xls", "compression_ratio_db3_CT.xls", "compression_ratio_db4_CT.xls","compression_ratio_db5_CT.xls", "compression_ratio_db6_CT.xls","compression_ratio_db7_CT.xls", "compression_ratio_db8_CT.xls"];
%archivo_ACL = ["ACL_db1_US.xls","ACL_db2_US.xls", "ACL_sym2_US.xls", "ACL_sym4_US.xls", "ACL_coif1_US.xls", "ACL_bior2.2_US.xls", "ACL_bior2.4_US.xls"];
%archivo_entropy = ["entropy_sym2.xls", "entropy_sym3.xls", "entropy_sym4.xls", "entropy_sym5.xls", "entropy_sym6.xls", "entropy_sym7.xls", "entropy_sym8.xls"];
%archivo_entropy = ["entropy_coif1.xls", "entropy_coif2.xls"];
%archivo_entropy = ["entropy_bior1.1.xls", "entropy_bior1.3.xls", "entropy_bior1.5.xls", "entropy_bior2.2.xls", "entropy_bior2.4.xls", "entropy_bior2.6.xls", "entropy_bior2.8.xls", "entropy_bior3.1.xls", "entropy_bior3.3.xls", "entropy_bior3.5.xls", "entropy_bior3.7.xls", "entropy_bior3.9.xls", "entropy_bior4.4.xls", "entropy_bior5.5.xls", "entropy_bior6.8.xls"];
%mean_eficiencia = cell(1,7);
mean_ratio = cell(1,15);
%mean_ACL = cell(1,7);

for j=1:15

    ls = liftingScheme("Wavelet", wavelet_madre{1,j});

for i=1:10

image = dicomread(imagenes{1,i},'Frames','all');
image = image(:,:,1,1);

%Para pruebas sobre imagenes de Ultra Sonido (US)
%image = image(:,:,1,1); %Se selecciona el canal 1 (R) y 1 fotograma del estudio de US, para CT o MR se comenta esta linea

for k=1:lvl
    
    %[eficiencia(i,k), compression_ratio(i,k), ACL(i,k)] = Prueba_3_Huffman(k, image, ls);
    [compression_ratio(i,k)] = Prueba_3_Huffman(k, image, ls);
end
display(i);
end

%archivo_eficiencia = 'eficiencia.xlsx'; % Nombre del archivo xlsx
%writematrix(eficiencia, archivo_eficiencia{1,j}); % Guardar la matriz en el archivo xlsx
%archivo_ratio = 'compression_ratio.xlsx'; % Nombre del archivo xlsx
%writematrix(compression_ratio, archivo_ratio{1,j}); % Guardar la matriz en el archivo xlsx
%archivo_ACL = 'Acl.xlsx'; % Nombre del archivo xlsx
%writematrix(ACL, archivo_ACL{1,j}); % Guardar la matriz en el archivo xlsx

%mean_eficiencia{1,j}  = mean(eficiencia);
mean_ratio{1,j}  = mean(compression_ratio);
%mean_ACL{1,j}  = mean(ACL);
display(j);
end

%{
figure(1);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_eficiencia{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
%plot(1:lvl, mean_eficiencia{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
hold off
xlabel('Niveles de descomposición');
ylabel('Eficiencia de codificación (E)');
%legend('Promedio Entropía')
%legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4', 'bior3.3');
%legend('sym2','sym3','sym4','sym5','sym6','sym7','sym8');
%legend('coif1','coif2');
legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4');
%legend('bior1.1','bior1.3','bior1.5','bior2.2','bior2.4','bior2.6','bior2.8','bior3.1','bior3.3','bior3.5','bior3.7','bior3.9','bior4.4','bior5.5','bior6.8');
title('Eficiencia de Codificación (E) vs Niveles de Descomposición - US - Codificación Huffman');
%}

figure(1);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_ratio{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
hold off
xlabel('Niveles de descomposición');
ylabel('Relación de compresión (CR)');
%legend('Promedio Entropía')
%legend('db1','db2','db3','db4','db5','db6','db7','db8');
%legend('sym2','sym3','sym4','sym5','sym6','sym7','sym8');
%legend('coif1','coif2');
%legend('db1','db2','sym2','sym4','coif1','bior2.2', 'bior2.4');
legend('bior1.1','bior1.3','bior1.5','bior2.2','bior2.4','bior2.6','bior2.8','bior3.1','bior3.3','bior3.5','bior3.7','bior3.9','bior4.4','bior5.5','bior6.8');
%title('Relación de Compresión (CR) vs Niveles de Descomposición - CT - Codificación Huffman');

%{
figure(3);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_ACL{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
%plot(1:lvl, mean_ACL{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
hold off
xlabel('Niveles de descomposición');
ylabel('Longitud de código promedio (ACL)');
%legend('Promedio Entropía')
legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4');
%legend('sym2','sym3','sym4','sym5','sym6','sym7','sym8');
%legend('coif1','coif2');
%legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4','bior3.3');
%legend('bior1.1','bior1.3','bior1.5','bior2.2','bior2.4','bior2.6','bior2.8','bior3.1','bior3.3','bior3.5','bior3.7','bior3.9','bior4.4','bior5.5','bior6.8');
title('Longitud de Código Promedio (ACL) vs Niveles de Descomposición - US - Codificación Huffman');
%}