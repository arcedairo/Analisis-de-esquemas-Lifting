%function [compression_ratio, mse, psnr] = Prueba_lifting_update_first_cuantificador(lvl, x, lScheme)
%function[mse, psnr] = Prueba_3_cuantificador(lvl, x, lScheme)

x = dicomread("CT_Prostata_1.dcm"); %lee la imagen en el formato Para imágenes médicas DICOM
%x = x(:,:,1,1); %solo para imágenes US, para CT y MRI comentar esta línea
%x = x(1:100, 1:100);
%unique_img = unique(x);
lvl=1;  %define el numero de niveles de descomposición de la transformada
%lScheme = liftingScheme("Wavelet","bior2.2"); %define el esquema lifting
lCustom4 = liftingScheme('Wavelet','lazy');
%lCustom = liftingScheme('wavelet', 'lazy');
lCustom4.NormalizationFactors = [2.121320343559643 0.471404520791032];

updateStep1 = liftingStep('Type', 'update', 'Coefficients', [1/2], 'MaxOrder', 0);
predictStep3 = liftingStep('Type', 'predict', 'Coefficients',[-0.375 -1.125], 'MaxOrder', 1);
updateStep44 = liftingStep('Type', 'update', 'Coefficients', [-0.1172 -0.2057], 'MaxOrder', 1);
updateStep34 = liftingStep('Type', 'update', 'Coefficients', [-0.0447 -0.2332], 'MaxOrder', 3);
updateStep5 = liftingStep('Type', 'update', 'Coefficients',[-1/12 4/9 1/12], 'MaxOrder', 1);

%lCustom3 = addlift(lCustom3, updateStep44);
%lCustom3 = addlift(lCustom3, predictStep3);
%lCustom3 = addlift(lCustom3, updateStep1);    

lCustom4 = addlift(lCustom4, updateStep34);
lCustom4 = addlift(lCustom4, predictStep3);
lCustom4 = addlift(lCustom4, updateStep5);

[lod2,hid2,lor2,hir2] = ls2filt(lCustom);
bswfun(lod2,hid2,lor2,hir2,'plot');
%}
%function [mse, psnr] = Prueba_lifting_update_first_cuantificador(lvl, x, lScheme)
%[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lScheme, Level=lvl, Int2Int=true);
%}
[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lScheme, Level=lvl, Int2Int=true);%Calcula la transformada wavelet (coeficientes de aProximación y detalles)

approx_size = size(ll);
input_array_approx = reshape(ll,1,prod(approx_size));
 
for k=1:lvl
    detailsh_size{k} = size(lh{k});
    detailsv_size{k} = size(hl{k});
    detailsd_size{k} = size(hh{k});
    input_array_detailsh{k} = reshape(lh{k},1,prod(detailsh_size{k}));
    input_array_detailsv{k} = reshape(hl{k},1,prod(detailsv_size{k}));
    input_array_detailsd{k} = reshape(hh{k},1,prod(detailsd_size{k}));
end

detailsh = horzcat(input_array_detailsh{:}); %Concatenación de detalles horizontales de todos los niveles
detailsv = horzcat(input_array_detailsv{:}); %Concatenación de detalles verticales de todos los niveles
detailsd = horzcat(input_array_detailsd{:}); %Concatenación de detalles diagonales de todos los niveles

concatenated_coeficients = horzcat(input_array_approx, detailsh, detailsv, detailsd); %Arreglo de todos los coeficientes (detalles y aProximación) concatenados

U = unique(concatenated_coeficients);  %halla los simbolos
[counts_coef, ~] = histcounts(concatenated_coeficients, [U, max(U)+1]);
probability_coef = counts_coef / sum(counts_coef); %Halla las Probabilidades de cada símbolo
entropia = -sum(probability_coef.*log2(probability_coef));
bit_depth = 7; %número de bits/palabra código
quantization_levels = 2^(bit_depth);

[partition,codebook] = lloyds(concatenated_coeficients,quantization_levels); %Loyd quantize
%thresh = round(linspace(double(min(U)),double(max(U)), quantization_levels));
%thresh = multithresh(concatenated_coeficients,quantization_levels);
%valuesMax = [thresh max(concatenated_coeficients(:))];
quantized_coeficients = imquantize(concatenated_coeficients,partition, codebook);
unique_quantized = unique(quantized_coeficients);

Indices = zeros(size(quantized_coeficients));

for i = 1:length(quantized_coeficients)
    Indices(i) = find(unique_quantized == quantized_coeficients(i), 1);
end

Indices = Indices - 1;
encoded_data = string(dec2bin(Indices, bit_depth))';

%Recuperación
decoded_indices = bin2dec(encoded_data);
decoded_indices = decoded_indices +1;

for i = 1:length(decoded_indices)
    index = decoded_indices(i);
    decoded_quantized_coeficients(i) = unique_quantized(index);
end

recover_approx = decoded_quantized_coeficients(:,1:prod(approx_size)); 
recover_approx = reshape(recover_approx, approx_size);
long_details = length(detailsh);

recover_detailsh = decoded_quantized_coeficients(:,prod(approx_size)+1:prod(approx_size)+long_details);
recover_detailsv = decoded_quantized_coeficients(:,prod(approx_size)+long_details+1:prod(approx_size)+2*long_details);
recover_detailsd = decoded_quantized_coeficients(:,prod(approx_size)+2*long_details+1:prod(approx_size)+3*long_details);

recover_lh = cell(1,lvl);
recover_hl = cell(1,lvl);
recover_hh = cell(1,lvl);

recover_lh{1} = recover_detailsh(:,1:numel(lh{1}));
recover_hl{1} = recover_detailsv(:,1:numel(hl{1}));
recover_hh{1} = recover_detailsd(:,1:numel(hh{1}));

for k=2:lvl
   
   start_index = sum(cellfun(@numel, lh(1:k-1))) + 1;
   end_index = start_index + numel(lh{k}) - 1;
   recover_lh{k} = recover_detailsh(:,start_index:end_index);
   recover_hl{k} = recover_detailsv(:,start_index:end_index);
   recover_hh{k} = recover_detailsd(:,start_index:end_index);
   
end

for k=1:lvl
recover_lh{k} = reshape(recover_lh{k},size(lh{k}));
recover_hl{k} = reshape(recover_hl{k},size(hl{k}));
recover_hh{k} = reshape(recover_hh{k},size(hh{k}));
end  

recover_lh = recover_lh(:);
recover_hl = recover_hl(:);
recover_hh = recover_hh(:);

xrec = ilwt2(recover_approx,recover_lh,recover_hl,recover_hh,LiftingScheme=lScheme,Int2Int=true); %Imagen reconstruida

a=whos('x');
tipo = a.class;
%{
if strcmpi(tipo, 'uint16')
        xrec = uint16(xrec);
else
        xrec = int16(xrec);
end
%}
xrec = uint8(xrec);
mse = immse(x, xrec);

%num_bits = 16; %bits de la imagen de entrada (según uint16 o uint8)
%Relación de compresión (CR, compression ratio)
%original_bits = prod(size(x)) * num_bits; %numero de bits de la imagen original
%num_encoded_bits = numel(char(strjoin(encoded_data, ''))); %numero de bits de la imagen codificada
%compression_ratio = original_bits / num_encoded_bits;
%max_value = 65535;
max_value = 255; %uint8
psnr = 10*log10(max_value.^2/mse); 
%end