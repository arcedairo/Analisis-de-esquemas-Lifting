
lscdf = liftingScheme(Wavelet="bior2.2");
[LoD,HiD,LoR,HiR] = ls2filt(lscdf);
bswfun(LoD,HiD,LoR,HiR,'plot'); 

titles = ["Función scaling de análisis", "Función wavelet de análisis ", "Función scaling de síntesis", "Función wavelet de síntesis"];
for i = 1:4
    subplot(2, 2, i);  % Seleccionar la gráfica correspondiente
    title(titles(i));  % Asignar el nuevo título
end
