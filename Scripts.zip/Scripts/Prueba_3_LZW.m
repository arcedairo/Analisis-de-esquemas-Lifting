function [compression_ratio] = Prueba_3_LZW(lvl, x, lScheme)
%{
image = "US_ECHO_7.dcm";
x = dicomread(image, 'Frames','all');
x = x(:,:,1,1);
lvl=1;  %define el numero de niveles de descomPosición de la transformada
lScheme = liftingScheme("Wavelet","bior2.2"); %define un esquema lifting con la wavelet madre definida.
%}
[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lScheme, Level=lvl, Int2Int=true);%Calcula la transformada wavelet (coeficientes de aProximación y detalles)

approx_size = size(ll);
input_array_approx = reshape(ll,1,prod(approx_size));

for k=1:lvl
    detailsh_size{k} = size(lh{k});
    detailsv_size{k} = size(hl{k});
    detailsd_size{k} = size(hh{k});
    input_array_detailsh{k} = reshape(lh{k},1,prod(detailsh_size{k}));
    input_array_detailsv{k} = reshape(hl{k},1,prod(detailsv_size{k}));
    input_array_detailsd{k} = reshape(hh{k},1,prod(detailsd_size{k}));
end

detailsh = horzcat(input_array_detailsh{:}); %Concatenación de detalles horizontales de todos los niveles
detailsv = horzcat(input_array_detailsv{:}); %Concatenación de detalles verticales de todos los niveles
detailsd = horzcat(input_array_detailsd{:}); %Concatenación de detalles diagonales de todos los niveles
concatenated_coeficients = horzcat(input_array_approx, detailsh, detailsv, detailsd); %Arreglo de todos los coeficientes (detalles y aProximación) concatenado
%unique_vals_coef= unique(concatenated_coeficients);
%[counts_coef, ~] = histcounts(concatenated_coeficients, [unique_vals_coef, max(unique_vals_coef)+1]);
%probability_coef = counts_coef / sum(counts_coef); %Probabilidades de símbolo
   
maximum = max(concatenated_coeficients)+1;
coeficients = concatenated_coeficients-maximum;
coeficients_string = string(coeficients);
indexes = [];
W = []; 
U = unique(coeficients);
dict = string(U);
for i = 1:length(coeficients_string)
        k = coeficients_string(i);
        wk = strcat(W, k);
        
        if ismember(wk, dict)
            W = wk;
        else
            code = find(dict == W);
            indexes = [indexes, code];
            dict(length(dict)+1) = wk; 
            W = k;
        end
end
        code = find(dict == W);
        indexes = [indexes, code];
        indexes_final = indexes-1;
     
        %encoded_data = string(dec2bin(indexes_final))';
        %{
        a=whos('x');
        tipo = a.class;

        if strcmpi(tipo, 'uint8') || strcmp(tipo, 'int8')
        num_bits = 8;
        elseif strcmp(tipo, 'uint16') || strcmp(tipo, 'int16')
        num_bits = 16; 
        end
        %}
        num_bits = 16;
        original_bits = prod(size(x)) * num_bits; %numero de bits de la imagen original
        %encoded_bits = numel(char(strjoin(encoded_data,''))); %numero de bits de la imagen codificada
        encoded_bits = ceil(log2(length(indexes_final)))*length(indexes_final);
        compression_ratio = original_bits / encoded_bits; 

        %entropia = -sum(probability_coef.*log2(probability_coef));
        %ACL = encoded_bits/numel(concatenated_coeficients);
        %eficiencia = (entropia/ACL)*100;
end