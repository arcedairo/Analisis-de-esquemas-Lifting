image = "CT_Prostata_1";
%image = "MRI_Abdomen_2";
%image = "US_ECHO_4.dcm";
x = dicomread(image, 'Frames','all');
info = dicominfo(image);
modality = info.Modality;

if strcmpi(modality, 'US')
    x = x(:,:,:,1:3);
else 
    x = x;
end


lvl=1;  %define el numero de niveles de descomPosición de la transformada
lScheme = liftingScheme("Wavelet","bior3.1"); %define un esquema lifting con la wavelet madre definida. 
[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lScheme, Level=lvl, Int2Int=true);%Calcula la transformada wavelet (coeficientes de aProximación y detalles)

approx_size = size(ll);
input_array_approx = reshape(ll,1,prod(approx_size));

for k=1:lvl
    detailsh_size{k} = size(lh{k});
    detailsv_size{k} = size(hl{k});
    detailsd_size{k} = size(hh{k});
    input_array_detailsh{k} = reshape(lh{k},1,prod(detailsh_size{k}));
    input_array_detailsv{k} = reshape(hl{k},1,prod(detailsv_size{k}));
    input_array_detailsd{k} = reshape(hh{k},1,prod(detailsd_size{k}));
end

detailsh = horzcat(input_array_detailsh{:}); %Concatenación de detalles horizontales de todos los niveles
detailsv = horzcat(input_array_detailsv{:}); %Concatenación de detalles verticales de todos los niveles
detailsd = horzcat(input_array_detailsd{:}); %Concatenación de detalles diagonales de todos los niveles

concatenated_coeficients = horzcat(input_array_approx, detailsh, detailsv, detailsd); %Arreglo de todos los coeficientes (detalles y aProximación) concatenados

%Codificación
unique_vals_coef = unique(concatenated_coeficients); %Alfabeto de símbolos
[counts_coef, ~] = histcounts(concatenated_coeficients, [unique_vals_coef, max(unique_vals_coef)+1]);
probability_coef = counts_coef / sum(counts_coef); %Probabilidades de símbolo
dict_coef = huffmandict(unique_vals_coef, probability_coef); %Diccionario Huffman
huff_coef = huffmanenco(concatenated_coeficients, dict_coef);  %Coeficientes codificados

%Decodificación
dec_coef = huffmandeco(huff_coef, dict_coef); %Decodificación de los coeficientes

%Recuperación
recover_approx = dec_coef(:,1:prod(approx_size)); 
recover_approx = reshape(recover_approx, approx_size);
long_details = length(detailsh);

recover_detailsh = dec_coef(:,prod(approx_size)+1:prod(approx_size)+long_details);
recover_detailsv = dec_coef(:,prod(approx_size)+long_details+1:prod(approx_size)+2*long_details);
recover_detailsd = dec_coef(:,prod(approx_size)+2*long_details+1:prod(approx_size)+3*long_details);

recover_lh = cell(1,lvl);
recover_hl = cell(1,lvl);
recover_hh = cell(1,lvl);

recover_lh{1} = recover_detailsh(:,1:numel(lh{1}));
recover_hl{1} = recover_detailsv(:,1:numel(hl{1}));
recover_hh{1} = recover_detailsd(:,1:numel(hh{1}));

for k=2:lvl
   
   start_index = sum(cellfun(@numel, lh(1:k-1))) + 1;
   end_index = start_index + numel(lh{k}) - 1;
   recover_lh{k} = recover_detailsh(:,start_index:end_index);
   recover_hl{k} = recover_detailsv(:,start_index:end_index);
   recover_hh{k} = recover_detailsd(:,start_index:end_index);
   
end

for k=1:lvl
recover_lh{k} = reshape(recover_lh{k},size(lh{k}));
recover_hl{k} = reshape(recover_hl{k},size(hl{k}));
recover_hh{k} = reshape(recover_hh{k},size(hh{k}));
end  

recover_lh = recover_lh(:);
recover_hl = recover_hl(:);
recover_hh = recover_hh(:);

xrec = ilwt2(recover_approx,recover_lh,recover_hl,recover_hh,LiftingScheme=lScheme,Int2Int=true); %Imagen reconstruida

if strcmpi(modality, 'US')
   xrec = uint8(xrec);
   figure(1);
   set(gcf, 'Position', get(0, 'Screensize'));
   subplot(2,1,1);
   montage(x,"Size",[1 3]);
   title("Imagen original")
   subplot(2,1,2);
   montage(xrec,"Size",[1 3]);
   title("Imagen reconstruida")
else 
    figure(1);
    set(gcf, 'Position', get(0, 'Screensize'));
    subplot(1,2,1);
    imshow(x, []);
    title("Imagen original")
    subplot(1,2,2);
    imshow(xrec,[]);
    title("Imagen reconstruida")
end

%Parámetros de desempeño

% Mean Squared Error - MSE
if strcmpi(modality, 'US')
    x_original = x;
else
    x_original = double(x);
end

mse = immse(x_original,xrec);

% Relación de compresión (CR, compression ratio)
a=whos('x');
tipo = a.class;

if strcmpi(tipo, 'uint8') || strcmp(tipo, 'int8')
        num_bits = 8;
elseif strcmp(tipo, 'uint16') || strcmp(tipo, 'int16')
        num_bits = 16; 
end

original_bits = prod(size(x)) * num_bits; %numero de bits de la imagen original
encoded_bits = numel(huff_coef); %numero de bits de la imagen codificada

compression_ratio = original_bits / encoded_bits;

%Entropía
entropia = -sum(probability_coef.*log2(probability_coef));

%Eficiencia de compresión

symbol_lengths = cellfun('length', dict_coef(:,2)); %Longitudes de palabras codigo del diccionario Huffman
symbol_probabilities = reshape(probability_coef, size(symbol_lengths));  %Probabilidad de cada símbolo del diccionario

ACL = sum(symbol_lengths .* symbol_probabilities); %longitud de codigo promedio (ACL)

eficiencia = (entropia/ACL)*100;
