image = "CT_Prostata_1";
%image = "MRI_Seno_1";
%image = "US_ECHO_1.dcm";
x = dicomread(image, 'Frames','all');
info = dicominfo(image);
modality = info.Modality;

%x=x(1:50,1:50);

%{
if strcmpi(modality, 'US')
    x = x(:,:,:,1:3);
else 
    x = x;
end
%}
lvl=1;  %define el numero de niveles de descomPosición de la transformada
lScheme = liftingScheme("Wavelet","bior3.1"); %define un esquema lifting con la wavelet madre definida. 
[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lScheme, Level=lvl, Int2Int=true);%Calcula la transformada wavelet (coeficientes de aProximación y detalles)

approx_size = size(ll);
input_array_approx = reshape(ll,1,prod(approx_size));

for k=1:lvl
    detailsh_size{k} = size(lh{k});
    detailsv_size{k} = size(hl{k});
    detailsd_size{k} = size(hh{k});
    input_array_detailsh{k} = reshape(lh{k},1,prod(detailsh_size{k}));
    input_array_detailsv{k} = reshape(hl{k},1,prod(detailsv_size{k}));
    input_array_detailsd{k} = reshape(hh{k},1,prod(detailsd_size{k}));
end

detailsh = horzcat(input_array_detailsh{:}); %Concatenación de detalles horizontales de todos los niveles
detailsv = horzcat(input_array_detailsv{:}); %Concatenación de detalles verticales de todos los niveles
detailsd = horzcat(input_array_detailsd{:}); %Concatenación de detalles diagonales de todos los niveles

concatenated_coeficients = horzcat(input_array_approx, detailsh, detailsv, detailsd); %Arreglo de todos los coeficientes (detalles y aProximación) concatenado

% Codificación LZW 
%coeficients_string = string(concatenated_coeficients);

    %concatenated = [-10, -20, -30, 0, 0, 0, -889, -700, -700, -700, 700, 700, 700, 700, 500, 889, 889, 889, 700, 889, 700, 889, 700, 889, 700, 889, 0, 0, 0, 0, 0, 0, 0, -889, -900, -900, -900, -900, -900, 0,0,0,0,0,0,0,0,0,0,0,0,-900,-900,-900,-900,-900,-900, 889, -899, -899, -889, -900, -900, 0, 0, 0, 0, 0];
    maximum = max(concatenated_coeficients)+1;
    coeficients_string = string(concatenated_coeficients-maximum);
    keys_forward = unique(coeficients_string);
    %keys_cell = arrayfun(@(c) string(c), keys_forward, 'UniformOutput', false);
    %keys_cell_str = string(keys_forward);
    % keys = ["T", "H", "I", "S", "E"];
    codes = 0:length(keys_forward)-1;
    bin_codes = string(dec2bin(codes))';

    dict = dictionary(keys_forward, bin_codes);
    encoded_data = [];
    W = []; 
    
    for i = 1:length(coeficients_string)
        k = coeficients_string(i);
        %wk = [W, k];
        wk = strcat(W, k);
        
        if isKey(dict, wk)
            W = wk;
        else
            code = dict(W);
            encoded_data = [encoded_data, code];
            dd = dict.keys;
            test = prod(size(dict.keys));
            dict(wk) = dec2bin(prod(size(dict.keys)));
            W = k;
        end
    end
    
    if ~isempty(W)
        code = dict(W);
        encoded_data = [encoded_data, code];
    end

    %Decodificación - Recuperación

    num_entries = prod(size(dict.keys));
    reverse_values = values(dict);
    reverse_keys = keys(dict);

    reverse_dict = dictionary(reverse_values, reverse_keys);
    decoded_data = [];
    reverse_code = encoded_data(1);
    output = reverse_dict(reverse_code);
    decoded_data = [decoded_data, output];


for i = 2:length(encoded_data)
    prev_code = reverse_code;
    reverse_code = encoded_data(i);
    
    if  i <= num_entries
        entry = reverse_dict(reverse_code);
    else
        entry = [reverse_dict(prev_code), reverse_dict(prev_code)];
    end
   
    decoded_data = [decoded_data, entry];
    new_entry = [reverse_dict(prev_code), entry];
end

lzw_decoded = {};

for i = 1:length(decoded_data)
    str = decoded_data(i);
    if startsWith(str, "-")
        parts = split(str, "-");
        for j = 2:length(parts)
            lzw_decoded = [lzw_decoded, "-" + parts{j}];
        end

    else
        for j = 1:length(str)
            lzw_decoded = [lzw_decoded, str(j)];
        end
    end
end

lzw_decoded = double(lzw_decoded);
lzw_decoded_final = lzw_decoded + maximum;
Equal = isequal(concatenated_coeficients,lzw_decoded_final);

num_bits_org = numel(x)*16;
num_lzw_bits = numel(char(strjoin(encoded_data, '')));
compression_ratio = num_bits_org/num_lzw_bits;

%---Developed by Dairo Arce C. University of Cauca - 2023 -----%