lvl = 9; %numero de niveles de descomposición
wav= ["db1","db2", "db3", "db4", "db5", "db6", "db7", "db8"]; %Arreglo donde se almacenan las wavelets madre de prueba

for i=1:8

for k=1:lvl
    
    [efficiency(i, k), ratio(i, k), entropy(i, k), code_word_length(i, k)] = calculate_efficiency(k, liftingScheme("Wavelet",wav(i)));

end

end

figure(1);
hold on
plot(1:lvl, efficiency(1,:), '-o');
plot(1:lvl, efficiency(2,:), '-*');
plot(1:lvl, efficiency(3,:), '-x');
plot(1:lvl, efficiency(4,:), '-+');
plot(1:lvl, efficiency(5,:), '-^');
plot(1:lvl, efficiency(6,:), '-s');
plot(1:lvl, efficiency(7,:), '-d');
plot(1:lvl, efficiency(8,:), '-p');
hold off
xlabel('lvl (Niveles de descomposición)');
ylabel('Eficiencia de compresión');
%legend('db4', 'sym4', 'haar', 'coif2', 'bior3.5');
legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
title('Eficiencia de compresión en función de los niveles de descomposición y wavelet madre');


figure(2);
hold on
plot(1:lvl, ratio(1,:), '-o');
plot(1:lvl, ratio(2,:), '-*');
plot(1:lvl, ratio(3,:), '-x');
plot(1:lvl, ratio(4,:), '-+');
plot(1:lvl, ratio(5,:), '-^');
plot(1:lvl, ratio(6,:), '-s');
plot(1:lvl, ratio(7,:), '-d');
plot(1:lvl, ratio(8,:), '-p');
hold off
xlabel('lvl (Niveles de descomposición)');
ylabel('Relación de compresión');
%legend('db4', 'sym4', 'haar', 'coif2', 'bior3.5');
legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
title('Relación de compresión en función de los niveles de descomposición y wavelet madre');


figure(3);
hold on
plot(1:lvl, entropy(1,:), '-o');
plot(1:lvl, entropy(2,:), '-*');
plot(1:lvl, entropy(3,:), '-x');
plot(1:lvl, entropy(4,:), '-+');
plot(1:lvl, entropy(5,:), '-^');
plot(1:lvl, entropy(6,:), '-s');
plot(1:lvl, entropy(7,:), '-d');
plot(1:lvl, entropy(8,:), '-p');
hold off
xlabel('lvl (Niveles de descomposición)');
ylabel('Entropía');
%legend('db4', 'sym4', 'haar', 'coif2', 'bior3.5');
legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
title('Entropía en función de los niveles de descomposición y wavelet madre');

figure(4);
hold on
plot(1:lvl, code_word_length(1,:), '-o');
plot(1:lvl, code_word_length(2,:), '-*');
plot(1:lvl, code_word_length(3,:), '-x');
plot(1:lvl, code_word_length(4,:), '-+');
plot(1:lvl, code_word_length(5,:), '-^');
plot(1:lvl, code_word_length(6,:), '-s');
plot(1:lvl, code_word_length(7,:), '-d');
plot(1:lvl, code_word_length(8,:), '-p');
hold off
xlabel('lvl (Niveles de descomposición)');
ylabel('Longitud de palabra codigo promedio');
%legend('db4', 'sym4', 'haar', 'coif2', 'bior3.5');
legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
title('Longitud de plalabra código promedio en función de los niveles de descomposición y wavelet madre');
   