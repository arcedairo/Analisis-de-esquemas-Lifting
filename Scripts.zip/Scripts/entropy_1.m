function [entropia] = entropy(lvl, x)

%x = dicomread('CT_Torax_1.dcm'); %lee la imagen en el formato Para imágenes médicas DICOM
%x = x(:,:,1); %selecciona la Primera caPa en la imagen.

%lvl=2;  %define el numero de niveles de descomPosición de la transformada
lScheme = liftingScheme("Wavelet","haar"); %define un esquema lifting con wavelet madre bior3.7
[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lScheme, Level=lvl, Int2Int=true);

approx_size = size(ll);
input_array_approx = reshape(ll,1,prod(approx_size));

for k=1:lvl
    detailsh_size{k} = size(lh{k});
    detailsv_size{k} = size(hl{k});
    detailsd_size{k} = size(hh{k});
    input_array_detailsh{k} = reshape(lh{k},1,prod(detailsh_size{k}));
    input_array_detailsv{k} = reshape(hl{k},1,prod(detailsv_size{k}));
    input_array_detailsd{k} = reshape(hh{k},1,prod(detailsd_size{k}));
end

detailsh = horzcat(input_array_detailsh{:}); %Concatena los detalles horizontales de todos los niveles en un solo arreglo
detailsv = horzcat(input_array_detailsv{:}); %Concatena los detalles verticales de todos los niveles en un solo arreglo
detailsd = horzcat(input_array_detailsd{:}); %Concatena los detalles diagonales de todos los niveles en un solo arreglo

concatenated_coeficients = horzcat(input_array_approx, detailsh, detailsv, detailsd); %Vector fila con todos los coeficientes (detalles y aProximación) concatenados

unique_vals_coef = unique(concatenated_coeficients);  %Se crea el alfabeto de símbolos
[counts_coef, ~] = histcounts(concatenated_coeficients, [unique_vals_coef, max(unique_vals_coef)+1]);
probability_coef = counts_coef / sum(counts_coef); %Halla las Probabilidades de cada símbolo

entropia = -sum(probability_coef.*log2(probability_coef));

end

%-----Developed by Dairo Arce C. University of Cauca, 2023 --------%