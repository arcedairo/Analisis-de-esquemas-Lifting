lvl=7;

%imagenes = ["CT_Torax_1.dcm", "CT_Prostata_1.dcm", "CT_Pediatrica_1.dcm", "CT_Cerebral_1.dcm", "CT_Cerebral_2.dcm", "CT_Abdomen_1.dcm", "CT_Abdomen_2.dcm", "CT_Abdomen_3.dcm","CT_Abdomen_4.dcm","CT_Abdomen_5.dcm"];
%imagenes = ["MRI_Seno_1.dcm", "MRI_Rinon_1.dcm", "MRI_Pelvis_1.dcm", "MRI_Pelvis_2.dcm", "MRI_Pancreas_1.dcm", "MRI_Cerebral_1.dcm", "MRI_Cerebral_2.dcm", "MRI_Cerebral_3.dcm","MRI_Abdomen_1.dcm","MRI_Abdomen_2.dcm"];
imagenes = ["US_ECHO_1.dcm", "US_ECHO_2.dcm", "US_ECHO_3.dcm", "US_ECHO_4.dcm", "US_ECHO_5.dcm", "US_ECHO_6.dcm", "US_ECHO_7.dcm", "US_ECHO_8.dcm","US_ECHO_9.dcm","US_ECHO_10.dcm"];
%wavelet_madre = ["db1", "db2", "sym2", "sym4", "coif1", "bior2.2", "bior2.4", "bior3.3"];
%wavelet_madre = ["db2", "db3", "sym4", "sym5", "coif1", "bior3.1", "bior3.3"];
%wavelet_madre = ["bior3.1", "bior3.3", "sym4", "sym5", "db2", "db3", "coif1"];
%wavelet_madre = ["db1", "db2", "db3", "db4", "db5", "db6", "db7", "db8"];
%wavelet_madre = ["sym2", "sym3", "sym4", "sym5", "sym6", "sym7", "sym8"];
%wavelet_madre = ["bior1.1", "bior1.3","bior1.5", "bior2.2", "bior2.4", "bior2.6", "bior2.8", "bior3.1", "bior3.3", "bior3.5", "bior3.7", "bior3.9", "bior4.4", "bior5.5", "bior6.8"];
wavelet_madre = ["coif1", "coif2"];
%archivo_MSE = ["mse_db1_cuantizador_US.xls", "mse_db2_cuantizador_US.xls", "mse_db3_cuantizador_US.xls", "mse_db4_cuantizador_US.xls", "mse_db5_cuantizador_US.xls", "mse_db6_cuantizador_US.xls", "mse_db7_cuantizador_US.xls", "mse_db8_cuantizador_US.xls"];
%archivo_MSE = ["mse_sym2_cuantizador_US.xls", "mse_sym3_cuantizador_US.xls", "mse_sym4_cuantizador_US.xls", "mse_sym5_cuantizador_US.xls", "mse_sym6_cuantizador_US.xls", "mse_sym7_cuantizador_US.xls", "mse_sym8_cuantizador_US.xls"];
archivo_MSE = ["mse_cuantizador_coif1_US.xls", "mse_cuantizador_coif2_US.xls"];
%archivo_MSE = ["mse_cuantificador_bior1.1_US.xls", "mse_cuantificador_bior1.3_US.xls","mse_cuantificador_bior1.5_US.xls", "mse_cuantificador_bior2.2_US.xls", "mse_cuantificador_bior2.4_US.xls", "mse_cuantificador_bior2.6_US.xls", "mse_cuantificador_bior2.8_US.xls", "mse_cuantificador_bior3.1_US.xls", "mse_cuantificador_bior3.3_US.xls", "mse_cuantificador_bior3.5_US.xls", "mse_cuantificador_bior3.7_US.xls", "mse_cuantificador_bior3.9_US.xls", "mse_cuantificador_bior4.4_US.xls", "mse_cuantificador_bior5.5_US.xls", "mse_cuantificador_bior6.8_US.xls"];

%archivo_eficiencia = ["eficiencia_db1_cuantizador_CT.xls", "eficiencia_db2_cuantizador_CT.xls", "eficiencia_db3_cuantizador_CT.xls", "eficiencia_db4_cuantizador_CT.xls", "eficiencia_db5_cuantizador_CT.xls", "eficiencia_db6_cuantizador_CT.xls", "eficiencia_db7_cuantizador_CT.xls", "eficiencia_db8"];
%archivo_ratio = ["compression_ratio_bior1.1_cuantizador_US.xls", "compression_ratio_bior1.3_cuantizador_US.xls", "compression_ratio_bior1.5_cuantizador_US.xls", "compression_ratio_bior2.2_cuantizador_US.xls", "compression_ratio_bior2.4_cuantizador_US.xls", "compression_ratio_bior2.6_cuantizador_US.xls", "compression_ratio_bior2.8_cuantizador_US.xls", "compression_ratio_bior3.1_cuantizador_US.xls", "compression_ratio_bior3.3_cuantizador_US.xls", "compression_ratio_bior3.5_cuantizador_US.xls", "compression_ratio_bior3.7_cuantizador_US.xls", "compression_ratio_bior3.9_cuantizador_US.xls", "compression_ratio_bior4.4_cuantizador_US.xls", "compression_ratio_bior5.5_cuantizador_US.xls", "compression_ratio_bior6.8_cuantizador_US.xls"];
%{
archivo_ACL = ["ACL_db1_cuantizador_US.xls", "ACL_db2_cuantizador_US.xls", "ACL_sym2_cuantizador_US.xls", "ACL_sym4_cuantizador_US.xls", "ACL_coif1_cuantizador_US.xls", "ACL_bior2.2_cuantizador_US.xls", "ACL_bior2.4_cuantizador_US.xls", "ACL_bior3.3_cuantizador_US.xls"];
archivo_MSE = ["mse_db1_cuantizador_US.xls", "mse_db2_cuantizador_US.xls", "mse_sym2_cuantizador_US.xls", "mse_sym4_cuantizador_US.xls", "mse_coif1_cuantizador_US.xls", "mse_bior2.2_cuantizador_US.xls", "mse_bior2.4_cuantizador_US.xls", "mse_bior3.3_cuantizador_US.xls"];
%}
archivo_ratio = ["compression_ratio_coif1_cuantizador_US.xls", "compression_ratio_coif2_cuantizador_US.xls"];
%archivo_psnr = ["psnr_bior1.1_cuantizador_US.xls", "psnr_bior1.3_cuantizador_US.xls", "psnr_bior1.5_cuantizador_US.xls", "psnr_bior2.2_cuantizador_US.xls", "psnr_bior2.4_cuantizador_US.xls", "psnr_bior2.6_cuantizador_US.xls", "psnr_bior2.8_cuantizador_US.xls", "psnr_bior3.1_cuantizador_US.xls", "psnr_bior3.3_cuantizador_US.xls", "psnr_bior3.5_cuantizador_US.xls", "psnr_bior3.7_cuantizador_US.xls", "psnr_bior3.9_cuantizador_US.xls", "psnr_bior4.4_cuantizador_US.xls", "psnr_bior5.5_cuantizador_US.xls", "psnr_bior6.8_cuantizador_US.xls"];
archivo_psnr = ["psnr_coif1_cuantizador_US.xls", "psnr_coif2_cuantizador_US.xls"];
%mean_eficiencia = cell(1,8);
mean_ratio = cell(1,2);
%mean_ACL = cell(1,8);
mean_mse = cell(1,2);
mean_psnr = cell(1,2);

for j=1:2

    ls = liftingScheme("Wavelet", wavelet_madre{1,j});

for i=1:10

image = dicomread(imagenes{1,i},'Frames','all');
image = image(:,:,1,1);

for k=1:lvl
   
   % [eficiencia(i,k), compression_ratio(i,k), ACL(i,k), mse(i,k), psnr(i,k)] = Prueba_3_cuantificador(k, image, ls);
   [compression_ratio(i,k),  mse(i,k), psnr(i,k)] = Prueba_3_cuantificador(k, image, ls); 
   display(k);
end

 display(i);

end

%writematrix(eficiencia, archivo_eficiencia{1,j}); % Guardar la matriz en el archivo xlsx
writematrix(compression_ratio, archivo_ratio{1,j}); % Guardar la matriz en el archivo xlsx
%writematrix(ACL, archivo_ACL{1,j}); % Guardar la matriz en el archivo xlsx
writematrix(mse, archivo_MSE{1,j});
writematrix(psnr, archivo_psnr{1,j});

%writematrix(mse, archivo_MSE{1,j});
%max_value = 65535;
%mean_eficiencia{1,j}  = mean(eficiencia);
mean_ratio{1,j}  = mean(compression_ratio);
%mean_ACL{1,j}  = mean(ACL);
mean_mse{1,j} = mean(mse);
mean_psnr{1,j} = mean(psnr);
display(j);
end

figure(1);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_mse{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
%{
plot(1:lvl, mean_mse{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
%}
hold off
xlabel('Niveles de descomposición');
ylabel('Error cuadrático medio (MSE)');
%legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
%legend('sym2', 'sym3', 'sym4', 'sym5', 'sym6', 'sym7', 'sym8');
%legend('bior1.1', 'bior1.3','bior1.5', 'bior2.2', 'bior2.4', 'bior2.6', 'bior2.8', 'bior3.1', 'bior3.3', 'bior3.5', 'bior3.7', 'bior3.9', 'bior4.4', 'bior5.5', 'bior6.8');
%legend('bior3.1', 'bior3.3', 'sym4', 'sym5', 'db2', 'db3', 'coif1');
%legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4', 'bior3.3');
legend('coif1', 'coif2');
title('Error Cuadrático Medio (MSE) vs Niveles de Descomposición');
%{
figure(1);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_eficiencia{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
plot(1:lvl, mean_eficiencia{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
hold off
xlabel('Niveles de descomposición');
ylabel('Eficiencia de codificación (E)');
legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
%legend('bior3.1', 'bior3.3', 'sym4', 'sym5', 'db2', 'db3', 'coif1');
%legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4', 'bior3.3');
title('Eficiencia de Codificación (E) vs Niveles de Descomposición');
%}
%{
figure(2);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_ACL{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
plot(1:lvl, mean_ACL{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
hold off
xlabel('Niveles de descomposición');
ylabel('Longitud de código promedio (ACL)');
legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
%legend('sym2', 'sym3', 'sym4', 'sym5', 'sym6', 'sym7', 'sym8');
%legend('bior3.1', 'bior3.3', 'sym4', 'sym5', 'db2', 'db3', 'coif1');
%legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4', 'bior3.3');
title('Longitud de Código Promedio (ACL) vs Niveles de Descomposición');
%}

figure(3);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_ratio{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
%{
plot(1:lvl, mean_ratio{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
plot(1:lvl, mean_ratio{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
%}
hold off
xlabel('Niveles de descomposición');
ylabel('Relación de compresión (CR)');
%legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
%legend('sym2', 'sym3', 'sym4', 'sym5', 'sym6', 'sym7', 'sym8');
%legend('bior3.1', 'bior3.3', 'sym4', 'sym5', 'db2', 'db3', 'coif1');
%legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4', 'bior3.3');
%legend('bior1.1', 'bior1.3','bior1.5', 'bior2.2', 'bior2.4', 'bior2.6', 'bior2.8', 'bior3.1', 'bior3.3', 'bior3.5', 'bior3.7', 'bior3.9', 'bior4.4', 'bior5.5', 'bior6.8');
legend('coif1', 'coif2');
title('Relación de Compresión (CR) vs Niveles de Descomposición');

%{
figure(4);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_mse{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
%plot(1:lvl, mean_entropy{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
hold off
xlabel('Niveles de descomposición');
ylabel('Error Cuadrático Medio (MSE)');
legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
%legend('sym2', 'sym3', 'sym4', 'sym5', 'sym6', 'sym7', 'sym8');
%legend('bior3.1', 'bior3.3', 'sym4', 'sym5', 'db2', 'db3', 'coif1');
%legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4', 'bior3.3');
title('Error Cuadrático Medio (MSE) vs Niveles de Descomposición');
%}

figure(5);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_psnr{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
%{
plot(1:lvl, mean_psnr{:,3},'-x', 'color', '#2ca02c', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,4},'-*', 'color', '#d62728', 'LineWidth', 1.1);%
plot(1:lvl, mean_psnr{:,5},'-hexagram', 'color', '#9467bd', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,6},'-square', 'color', '#8c564b', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,7},'-diamond', 'color', '#e377c2', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,8},'-pentagram', 'color', '#7f7f7f', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,9},'-o', 'color', '#bcbd22', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,10},'-+', 'color', '#17becf', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,11},'-x', 'color', '#1b9e77', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,12},'-*', 'color', '#aec7e8', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,13},'-hexagram', 'color', '#ffbb78', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,14},'-square', 'color', '#98df8a', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,15},'-diamond', 'color', '#ff9896', 'LineWidth', 1.1);
%}
hold off
xlabel('Niveles de descomposición');
ylabel('Relación máxima señal a ruido (PSNR)');
%legend('db1', 'db2', 'db3', 'db4', 'db5', 'db6', 'db7', 'db8');
%legend('sym2', 'sym3', 'sym4', 'sym5', 'sym6', 'sym7', 'sym8');
%legend('bior3.1', 'bior3.3', 'sym4', 'sym5', 'db2', 'db3', 'coif1');
%legend('db1','db2','sym2','sym4','coif1','bior2.2','bior2.4', 'bior3.3');
%legend('bior1.1', 'bior1.3','bior1.5', 'bior2.2', 'bior2.4', 'bior2.6', 'bior2.8', 'bior3.1', 'bior3.3', 'bior3.5', 'bior3.7', 'bior3.9', 'bior4.4', 'bior5.5', 'bior6.8');
legend('coif1', 'coif2');
title('Relación Máxima Señal a Ruido (PSNR) vs Niveles de Descomposición');