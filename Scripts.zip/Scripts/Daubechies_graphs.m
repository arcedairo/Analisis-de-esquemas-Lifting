wname = 'sym2';
iter = 10;

[phi,psi,xval] = wavefun(wname,iter); %calcula la función Wavelet y Scaling

figure;
plot(xval, psi, 'r-', 'LineWidth', 1.5); % Gráfica de función la Wavelet
hold on;
set(gcf,'color','w');
plot(xval, phi, 'b-', 'LineWidth', 1.5); % Gráfica de la función Scaling
hold off;
title(['Función Wavelet y Scaling de ', wname]);
xlabel('Valores de x');
ylabel('Amplitud');
legend('Wavelet', 'Scaling');
grid on;