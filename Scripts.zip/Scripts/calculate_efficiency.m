function [compression_efficiency, compression_ratio, entropy_coded_image, average_coded_length] = calculate_efficiency(lvl, lScheme)

x = dicomread("Cr_Urografia_2.dcm"); %lee la imagen en el formato Para imágenes médicas DICOM
x = x(:,:,1); %selecciona la Primera caPa en la imagen. 

lvl=3;  %define el numero de niveles de descomPosición de la transformada
lScheme = liftingScheme("Wavelet","db4"); %define un esquema lifting con wavelet madre db4


[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lScheme, Level=lvl, Int2Int=true); %calcula la transformada wavelet (y los coeficientes de aProximación y detalles) de la imagen x con elesquema lifitng y niveles definidos, conserva las muestras enteras, es decir, se aPlica la Integer Lifting Wavelet Transform
approxDiffs = ll-floor(ll); %calcula la diferencia entre los coeficientes de aproximación y sus valores enteros para asegurar que sea cero. 
max(abs(approxDiffs(:)));  %calcula el valor máximo de la diferencia, este valor debe ser cero.

%-----ImPlementación del esquema de codificación (comPresión) Huffman-----%

approx_size = size(ll);
input_array_approx = reshape(ll,1,prod(approx_size));

for k=1:lvl
    detailsh_size{k} = size(lh{k});
    detailsv_size{k} = size(hl{k});
    detailsd_size{k} = size(hh{k});
    input_array_detailsh{k} = reshape(lh{k},1,prod(detailsh_size{k}));
    input_array_detailsv{k} = reshape(hl{k},1,prod(detailsv_size{k}));
    input_array_detailsd{k} = reshape(hh{k},1,prod(detailsd_size{k}));
end

detailsh = horzcat(input_array_detailsh{:}); %Concatena los detalles horizontales de todos los niveles en un solo arreglo
detailsv = horzcat(input_array_detailsv{:}); %Concatena los detalles verticales de todos los niveles en un solo arreglo
detailsd = horzcat(input_array_detailsd{:}); %Concatena los detalles diagonales de todos los niveles en un solo arreglo

concatenated_coeficients = horzcat(input_array_approx, detailsh, detailsv, detailsd); %Vector fila con todos los coeficientes (detalles y aProximación) concatenados

%El arreglo de coeficientes concatenados se usa Para crear el diccionario
%de codificación Huffman

unique_vals_coef = unique(concatenated_coeficients);  %halla los simbolos Para el diccionario Huffman
[counts_coef, ~] = histcounts(concatenated_coeficients, [unique_vals_coef, max(unique_vals_coef)+1]);
probability_coef = counts_coef / sum(counts_coef); %Halla las Probabilidades de cada símbolo
dict_coef = huffmandict(unique_vals_coef, probability_coef); %Crea el diccionario Huffman para la codificación
huff_coef = huffmanenco(concatenated_coeficients, dict_coef);  %Arreglo de coeficientes codificados con Huffman

entropy_coded_image = -sum(probability_coef.*log2(probability_coef));
%Decodificación Huffman

dec_coef = huffmandeco(huff_coef, dict_coef); %decodificación de los coeficientes wavelet. 

%Recuperación los coeficientes de aproximación
recover_approx = dec_coef(:,1:prod(approx_size)); 
recover_approx = reshape(recover_approx, approx_size);
long_details = length(detailsh);
% RecuPeración de los coeficientes de detalle
recover_detailsh = dec_coef(:,prod(approx_size)+1:prod(approx_size)+long_details);
recover_detailsv = dec_coef(:,prod(approx_size)+long_details+1:prod(approx_size)+2*long_details);
recover_detailsd = dec_coef(:,prod(approx_size)+2*long_details+1:prod(approx_size)+3*long_details);

recover_lh = cell(1,lvl);
recover_hl = cell(1,lvl);
recover_hh = cell(1,lvl);

recover_lh{1} = recover_detailsh(:,1:numel(lh{1}));
recover_hl{1} = recover_detailsv(:,1:numel(hl{1}));
recover_hh{1} = recover_detailsd(:,1:numel(hh{1}));

for k=2:lvl
   
   start_index = sum(cellfun(@numel, lh(1:k-1))) + 1;
   end_index = start_index + numel(lh{k}) - 1;
   recover_lh{k} = recover_detailsh(:,start_index:end_index);
   recover_hl{k} = recover_detailsv(:,start_index:end_index);
   recover_hh{k} = recover_detailsd(:,start_index:end_index);
   
end

%recover_lh{2} = recover_detailsh(:,numel(lh{1})+1:numel(lh{1})+numel(lh{2}));
%recover_lh{3} = recover_detailsh(:,numel(lh{1})+numel(lh{2})+1:numel(lh{1})+numel(lh{2})+numel(lh{3}));

for k=1:lvl
recover_lh{k} = reshape(recover_lh{k},size(lh{k}));
recover_hl{k} = reshape(recover_hl{k},size(hl{k}));
recover_hh{k} = reshape(recover_hh{k},size(hh{k}));
end  

recover_lh = recover_lh(:);
recover_hl = recover_hl(:);
recover_hh = recover_hh(:);

recon_img = ilwt2(recover_approx,recover_lh,recover_hl,recover_hh,LiftingScheme=lScheme,Int2Int=true);

recHuffDiffs = recon_img-floor(recon_img); 
max(abs(recHuffDiffs(:)));

%{
figure(1);
set(gcf, 'Position', get(0, 'Screensize'));
subplot(1,2,1);
imshow(x, []);
title("Imagen de entrada")
subplot(1,2,2);
imshow(recon_img,[]);
title("Imagen Huffman reconstruida")

figure(2);
% Graficar los coeficientes de detalles en el primer nivel
set(gcf, 'Position', get(0, 'Screensize'));
subplot(2, 2, 1);
imshow(recover_approx,[]);
title('Aproximación');
subplot(2, 2, 2);
imshow(recover_lh{1}, []);
title('Detalles horizontales nivel 1');
subplot(2, 2, 3);
imshow(recover_hl{1}, []);
title('Detalles verticales nivel 1');
subplot(2, 2, 4);
imshow(recover_hh{1}, []);
title('Detalles diagonales nivel 1');

figure(3);
% Graficar los coeficientes de detalles en el segundo nivel
set(gcf, 'Position', get(0, 'Screensize'));
subplot(2, 2, 1);
imshow(recover_approx,[]);
title('Aproximación');
subplot(2, 2, 2);
imshow(recover_lh{2}, []);
title('Detalles horizontales nivel 2');
subplot(2, 2, 3);
imshow(recover_hl{2}, []);
title('Detalles verticales nivel 2');
subplot(2, 2, 4);
imshow(recover_hh{2}, []);
title('Detalles diagonales nivel 2');

figure(4);
% Graficar los coeficientes de detalles en el tercer nivel
set(gcf, 'Position', get(0, 'Screensize'));
subplot(2, 2, 1);
imshow(recover_approx,[]);
title('Aproximación');
subplot(2, 2, 2);
imshow(recover_lh{3}, []);
title('Detalles horizontales nivel 3');
subplot(2, 2, 3);
imshow(recover_hl{3}, []);
title('Detalles verticales nivel 3');
subplot(2, 2, 4);
imshow(recover_hh{3}, []);
title('Detalles diagonales nivel 3');
%}
original_image = double(x); %convierte la imagen de entrada en double

%Calculo de la MSE 

error_cuadratico = (original_image - recon_img).^2;
mse = sum(error_cuadratico(:)) / numel(x);

mse2 = immse(original_image,recon_img);   %El valor de la MSE es cero, por lo que la PSNR tiende a ser infinito. Se tiene reconstrucción perfecta. 
%Cálculo de la PSNR
 
%maxval = max(x);
%psnr = 10*log10(max.^2/mse);    

%Cálculo del SSIM

ssim_index = ssim(original_image,recon_img); %El indice de similitud estructural SSIM es 1, lo que confirma la reconstrucción perfecta. 
equal = isequal(original_image,recon_img);
%una imagen tipo uint16 ocupa 2 bytes por pixel

%calculo de la relación de compresión

tam_org = whos("x");
tamano_org_bytes = tam_org.bytes; %tamaño de la imagen original en bytes

%tamaño en bytes de la imagen comprimida
recon_img_uint16 = uint16(recon_img);
tamano_comp = whos("recon_img_uint16");
tamano_comp_bytes = tamano_comp.bytes;

relac_compresion = tamano_org_bytes/tamano_comp_bytes;

% Obtiene la información del histograma
[pixelCounts, grayLevels] = imhist(x); %imagen original
[pixelCountsRecons, grayLevelsRecons] = imhist(recon_img_uint16); %imagen reconstruida

%{
% Muestra el histograma
figure(5);
subplot(2,1,1);
bar(grayLevels, pixelCounts);
title('Histograma de la imagen DICOM original');
xlabel('Niveles de gris');
ylabel('Frecuencia');
subplot(2,1,2);
bar(grayLevelsRecons, pixelCountsRecons);
title('Histograma de la imagen reconstruida');
xlabel('Niveles de gris');
ylabel('Frecuencia');
%}

im = imhist(x);

% Cálculo de la entropía
e = entropy(x);
% Obtiene la distribución de probabilidades
pixelCountsOriginal = imhist(x) / numel(x); %Recuentos de histograma normalizados devueltos de la función imhist
entropyValue = -sum(pixelCountsOriginal .* log2(pixelCountsOriginal), 'omitnan'); %Entropia imagen original

pixelCountsRecons = imhist(recon_img_uint16) / numel(recon_img_uint16);
entropyValueRecons = -sum(pixelCountsRecons .* log2(pixelCountsRecons), 'omitnan'); %Entropia imagen reconstruida
rutaArchivoDICOM = 'recons.dcm';

dicomwrite(recon_img, rutaArchivoDICOM); %genera una imagen DICOM a partir de la reconstrucción de la imagen original

%Cálculo de la entropia de la información codificada

entropy_coded_image = -sum(probability_coef.*log2(probability_coef));

%Cálculo de la eficiencia de compresión

symbol_lengths = cellfun('length', dict_coef(:,2)); %Extrae las longitudes de los símbolos en el diccionario Huffman
symbol_probabilities = reshape(probability_coef, size(symbol_lengths)); %Probabilidad de cada símbolo en el diccionario

average_coded_length = sum(symbol_lengths .* symbol_probabilities); %longitud de palabras codigo promedio
%average_uncoded_length = log2(numel(unique_vals_coef));

%average_uncoded_length = -sum(symbol_probabilities .* log2(symbol_probabilities), 'omitnan');
%compression_efficiency = average_uncoded_length / average_coded_length;
compression_efficiency = (entropy_coded_image/average_coded_length)*100;

%Calculo de la relacion de compresión

original_bits = prod(size(x)) * 16; %numero de bits de la imagen original
encoded_bits = numel(huff_coef); %numero de bits de la imagen codificada

compression_ratio = original_bits / encoded_bits; %relación de compresión

%dictionary_length = length(dict_coef);

end