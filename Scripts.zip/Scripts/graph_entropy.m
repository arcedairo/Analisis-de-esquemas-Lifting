lvl=9;

imagenes = ["CT_Torax_1.dcm", "CT_Prostata_1.dcm", "CT_Pediatrica_1.dcm", "CT_Cerebral_1.dcm", "CT_Cerebral_2.dcm", "CT_Abdomen_1.dcm", "CT_Abdomen_2.dcm", "CT_Abdomen_3.dcm","CT_Abdomen_4.dcm","CT_Abdomen_5.dcm"];
%imagenes = ["CT_Torax_1.dcm", "CT_Prostata_1.dcm"];
%imagenes = ["MRI_Seno_1.dcm", "MRI_Rinon_1.dcm", "MRI_Pelvis_1.dcm", "MRI_Pelvis_2.dcm", "MRI_Pancreas_1.dcm", "MRI_Cerebral_1.dcm", "MRI_Cerebral_2.dcm", "MRI_Cerebral_3.dcm","MRI_Abdomen_1.dcm","MRI_Abdomen_2.dcm"];
%imagenes = ["US_ECHO_1.dcm", "US_ECHO_2.dcm", "US_ECHO_3.dcm", "US_ECHO_4.dcm", "US_ECHO_5.dcm", "US_ECHO_6.dcm", "US_ECHO_7.dcm", "US_ECHO_8.dcm","US_ECHO_9.dcm","US_ECHO_10.dcm"];

for i=1:10

image = dicomread(imagenes{1,i},'Frames','all');

%Para pruebas sobre imagenes de Ultra Sonido (US)
%image = image(:,:,:,1:3); %Se seleccionan los primeros 3 fotogramas del estudio de US, para CT o MR se comenta esta linea

for k=1:lvl
    
    [entropia(i, k)] = entropy_1(k, image);

end

end

archivo_entropy = 'entropia.xlsx'; % Nombre del archivo xlsx
writematrix(entropia, archivo_entropy); % Guardar la matriz en el archivo xlsx

mean_entropy  = mean(entropia);

figure(1);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, entropia(1,:), '-o', 'color', '#FF5733', 'LineWidth', 1);
plot(1:lvl, entropia(2,:), '-+', 'color', '#FF7D33', 'LineWidth', 1);
plot(1:lvl, entropia(3,:), '-x', 'color', '#FFF933', 'LineWidth', 1);
plot(1:lvl, entropia(4,:), '-*', 'color', '#7DFF33', 'LineWidth', 1);
plot(1:lvl, entropia(5,:), '-hexagram', 'color', '#33FF90', 'LineWidth', 1);
plot(1:lvl, entropia(6,:), '-square', 'color', '#33FFF0', 'LineWidth', 1);
plot(1:lvl, entropia(7,:), '-diamond', 'color', '#3333FF', 'LineWidth', 1);
plot(1:lvl, entropia(8,:), '-^', 'color', '#8033FF', 'LineWidth', 1);
plot(1:lvl, entropia(9,:), '->', 'color', '#F333FF', 'LineWidth', 1);
plot(1:lvl, entropia(10,:), '-pentagram', 'color', '#FF3342', 'LineWidth', 1);
hold off
xlabel('Niveles de descomposición');
ylabel('Entropía coeficientes wavelet');
title('Entropía Coeficientes Wavelet vs Niveles de Descomposición');
%legend('CT\_Torax\_1','CT\_Prostata\_1','CT\_Pediatrica\_1','Cr\_Cerebral\_1','CT\_Cerebral\_2','CT\_Abdomen\_1','CT\_Abdomen\_2','CT\_Abdomen\_3','CT\_Abdomen\_4','CT\_Abdomen\_5','Location', 'northeast')
%legend('MRI\_Seno\_1','MRI\_Riñon\_1','MRI\_Pelvis\_1','MRI\_Pelvis\_2','MRI\_Pancreas\_1','MRI\_Cerebral\_1','MRI\_Cerebral\_2','MRI\_Cerebral\_3','MRI\_Abdomen\_1','MRI\_Abdomen\_2','Location', 'northeast')
legend('US\_ECHO\_1','US\_ECHO\_2','US\_ECHO\_3','US\_ECHO\_4','US\_ECHO\_5','US\_ECHO\_6','US\_ECHO\_7','US\_ECHO\_8','US\_ECHO\_9','US\_ECHO\_10','Location', 'northeast')

figure(2);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_entropy,'-*', 'color', '#FF5733', 'LineWidth', 1.5);
hold off
xlabel('Niveles de descomposición');
ylabel('Entropía coeficientes wavelet');
legend('Promedio Entropía')
title('Entropía vs Niveles de Descomposición');