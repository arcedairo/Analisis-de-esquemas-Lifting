format short
disp('Descomponiendo imagen .....')

niveles = 2; 
%wav= ["haar","haar",];
img = dicomread("CT_Prostata_1.dcm");

conAtrasado = 0;
AllImg = cell(1,(1+(3*niveles)));   

    for i=1 : niveles
        %lScheme = liftingScheme("Wavelet",wav(i));
        lScheme = liftingScheme("Wavelet","haar");
        [ll,lh,hl,hh] = lwt2(img,LiftingScheme=lScheme,Level=1,Int2Int=true);
        
        AllImg{1 + (3*conAtrasado)} = lh{1};
        AllImg{2 + (3*conAtrasado)} = hl{1};        AllImg{3 + (3*conAtrasado)} = hh{1};

        conAtrasado = conAtrasado +1;

        img = img;
    end
    
    AllImg{(1+(3*niveles))} = ll;

    cellTemp = cell(1,4);
    contInv = length(AllImg);

while contInv > 1
    %AllImag

     %contInv
    
    if (contInv == length(AllImg))
        cellTemp{1} = AllImg{contInv-3};
        cellTemp{2} = AllImg{contInv-2};
        cellTemp{3} = AllImg{contInv-1};
        cellTemp{4} = AllImg{contInv};
        %cellTemp

        %cellTemp{1} = [cellTemp{4} cellTemp{1}; cellTemp{2} cellTemp{3}];
        cellTemp{1} = [uint8(cellTemp{4}) uint8(cellTemp{1}); uint8(cellTemp{2}) uint8(cellTemp{3})];
        
        contInv = contInv-4;


        %Recorte de las imagenes para poder mostrarlas
        if(contInv>0)

                cTem = cellTemp{1};
                cAll = AllImg{contInv};
                difPixF = size(cTem,1)-size(cAll,1);
                difPixC = size(cTem,2)-size(cAll,2);
        
                for i=1:difPixF
                    cellTemp{1}(i,:)=[];
                end
                for i=1:difPixC
                    cellTemp{1}(:,i)=[];
                end
        end
                
     
    else
        cellTemp{2} = AllImg{contInv-2};
        cellTemp{3} = AllImg{contInv-1};
        cellTemp{4} = AllImg{contInv};
        %cellTemp

        %Recorte de las imagenes para poder mostrarlas
        cTem = cellTemp{1};
        cAll = AllImg{contInv};
        difPixF = size(cTem,1)-size(cAll,1);
        difPixC = size(cTem,2)-size(cAll,2);

        for i=1:difPixF
            cellTemp{1}(i,:)=[];
        end
        for i=1:difPixC
            cellTemp{1}(:,i)=[];
        end
%_____________________________________________

   
        %cellTemp{1} = [cellTemp{1} (cellTemp{2}); cellTemp{3} cellTemp{4}];
        cellTemp{1} = [cellTemp{1} uint8(cellTemp{2}); uint8(cellTemp{3}) uint8(cellTemp{4})];
        
        contInv = contInv-3;
    end


end

figure(2);
imshow(ll,[]);
figure(541);
imshow(cellTemp{1},[]);
