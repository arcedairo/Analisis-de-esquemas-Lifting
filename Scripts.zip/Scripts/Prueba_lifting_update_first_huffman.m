
%x = dicomread("CT_Prostata_1.dcm"); %lee la imagen en el formato Para imágenes médicas DICOM
x = dicomread("US_ECHO_1.dcm", 'Frames','all');
x = x(:,:,1,1); %solo para imágenes US, para CT y MRI comentar esta línea
lvl=2; 

lCustom = liftingScheme('wavelet', 'lazy');
lCustom.NormalizationFactors = [2.121320343559643 0.471404520791032];

updateStep48 = liftingStep('Type', 'update', 'Coefficients', [-5.0873e-04 0.0019], 'MaxOrder', 5);
predictStep2 = liftingStep('Type', 'predict', 'Coefficients', [-1/2 -1/2], 'MaxOrder', 1);

updateStep3 = liftingStep('Type', 'update', 'Coefficients', [-1/3], 'MaxOrder', -1); %bior3.1
predictStep55 = liftingStep('Type', 'predict', 'Coefficients',[-0.3748 -1.1248], 'MaxOrder', 1); %bior3.1 modificado


%lCustom = addlift(lCustom, updateStep48);
%lCustom = addlift(lCustom, predictStep2);

lCustom = addlift(lCustom, updateStep3);
lCustom = addlift(lCustom, predictStep55);

[lod2,hid2,lor2,hir2] = ls2filt(lCustom);
bswfun(lod2,hid2,lor2,hir2,'plot');
%}
%function [compression_ratio] = Prueba_lifting_update_first_huffman(lvl, x, lScheme);

[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lCustom, Level=lvl, Int2Int=true);
%[ll,lh,hl,hh] = lwt2(x,LiftingScheme=lScheme, Level=lvl, Int2Int=true);


approx_size = size(ll);
input_array_approx = reshape(ll,1,prod(approx_size));

for k=1:lvl
    detailsh_size{k} = size(lh{k});
    detailsv_size{k} = size(hl{k});
    detailsd_size{k} = size(hh{k});
    input_array_detailsh{k} = reshape(lh{k},1,prod(detailsh_size{k}));
    input_array_detailsv{k} = reshape(hl{k},1,prod(detailsv_size{k}));
    input_array_detailsd{k} = reshape(hh{k},1,prod(detailsd_size{k}));
end

detailsh = horzcat(input_array_detailsh{:}); %Concatenación de detalles horizontales de todos los niveles
detailsv = horzcat(input_array_detailsv{:}); %Concatenación de detalles verticales de todos los niveles
detailsd = horzcat(input_array_detailsd{:}); %Concatenación de detalles diagonales de todos los niveles

concatenated_coeficients = horzcat(input_array_approx, detailsh, detailsv, detailsd); %Arreglo de todos los coeficientes (detalles y aProximación) concatenados
%concatenated_coeficients = [12, -889, -889, 0, 0, 0, 100, 200, 300, 400, 500, -700, -600, -250, -115, 20, -115, 20, -115, 20, 15, 20, 15, 20, 15, 20, 15, 20];
%Codificación
unique_vals_coef = unique(concatenated_coeficients); %Alfabeto de símbolos
[counts_coef, ~] = histcounts(concatenated_coeficients, [unique_vals_coef, max(unique_vals_coef)+1]);
probability_coef = counts_coef / sum(counts_coef); %Probabilidades de símbolo
dict_coef = huffmandict(unique_vals_coef, probability_coef); %Diccionario Huffman
huff_coef = huffmanenco(concatenated_coeficients, dict_coef);  %Coeficientes codificados

num_bits = 8;
original_bits = numel(x) * num_bits;  %numero de bits de la imagen original
encoded_bits = numel(huff_coef); %numero de bits de la imagen codificada

compression_ratio = original_bits / encoded_bits;

%Entropía
entropia = -sum(probability_coef.*log2(probability_coef));

%Eficiencia de compresión
symbol_lengths = cellfun('length', dict_coef(:,2)); %Longitudes de palabras codigo del diccionario Huffman
symbol_probabilities = reshape(probability_coef, size(symbol_lengths));  %Probabilidad de cada símbolo del diccionario

ACL = sum(symbol_lengths .* symbol_probabilities); %longitud de codigo promedio (ACL)

eficiencia = (entropia/ACL)*100;
%end