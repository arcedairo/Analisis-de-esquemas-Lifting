%lScheme2 = liftingScheme("Wavelet", "bior5.5");
%lScheme3 = liftingScheme("Wavelet", "db6");
%disp(lScheme);

predictStep1 = liftingStep('Type', 'predict', 'Coefficients', [-1], 'MaxOrder', 0); %haar
predictStep2 = liftingStep('Type', 'predict', 'Coefficients', [-1/2 -1/2], 'MaxOrder', 1); %bior2.2
predictStep3 = liftingStep('Type', 'predict', 'Coefficients',[-0.375 -1.125], 'MaxOrder', 1);%bior3.1
predictStep4 = liftingStep('Type', 'predict', 'Coefficients',-1.7321, 'MaxOrder', 0); %db2
predictStep5 = liftingStep('Type', 'predict', 'Coefficients',1, 'MaxOrder', -1); %db2
predictStep6 = liftingStep('Type', 'predict', 'Coefficients',-2.4255, 'MaxOrder', 0); %db3
predictStep7 = liftingStep('Type', 'predict', 'Coefficients',[2.8953 -0.5614], 'MaxOrder', -1); %db3
predictStep8 = liftingStep('Type', 'predict', 'Coefficients',-0.3223, 'MaxOrder', 1); %db4
predictStep9 = liftingStep('Type', 'predict', 'Coefficients',[-0.0188 0.1176], 'MaxOrder', 2); %db4
predictStep10 = liftingStep('Type', 'predict', 'Coefficients',[-0.4691 0.1400 -0.0248], 'MaxOrder', 0); %db4
predictStep11 = liftingStep('Type', 'predict', 'Coefficients',[-0.5341 0.2133], 'MaxOrder', 0); %db5
predictStep12 = liftingStep('Type', 'predict', 'Coefficients',[-0.0776 0.0121], 'MaxOrder', -2); %db5
predictStep13 = liftingStep('Type', 'predict', 'Coefficients',-4.4345, 'MaxOrder', 0); %db6
predictStep14 = liftingStep('Type', 'predict', 'Coefficients',[9.9700 -4.4931], 'MaxOrder', -1); %db6
predictStep15 = liftingStep('Type', 'predict', 'Coefficients',[2.3565 -0.6788], 'MaxOrder', -3); %db6
predictStep16 = liftingStep('Type', 'predict', 'Coefficients',0.0941, 'MaxOrder', -5); %db6
predictStep17 = liftingStep('Type', 'predict', 'Coefficients',[-0.1890 0.0574], 'MaxOrder', 0); %db7
predictStep18 = liftingStep('Type', 'predict', 'Coefficients',[-0.0604 0.0291], 'MaxOrder', -2); %db7
predictStep19 = liftingStep('Type', 'predict', 'Coefficients',[-0.0127 0.0033], 'MaxOrder', -4); %db7
predictStep20 = liftingStep('Type', 'predict', 'Coefficients',-4.0621e-04, 'MaxOrder', -6); %db7
predictStep21 = liftingStep('Type', 'predict', 'Coefficients',-5.7496, 'MaxOrder', 0); %db8
predictStep22 = liftingStep('Type', 'predict', 'Coefficients',[14.5428 -7.4021], 'MaxOrder', -1); %db8
predictStep23 = liftingStep('Type', 'predict', 'Coefficients',[5.8187 -2.7557], 'MaxOrder', -3); %db8
predictStep24 = liftingStep('Type', 'predict', 'Coefficients',[1.8884e-04 -0.0018], 'MaxOrder', -3); %db8
predictStep25 = liftingStep('Type', 'predict', 'Coefficients',[1.0497 -0.2470 0.0272], 'MaxOrder', -5); %db8
predictStep26 = liftingStep('Type', 'predict', 'Coefficients',-1.7321, 'MaxOrder', 0); %sym2
predictStep27 = liftingStep('Type', 'predict', 'Coefficients',1, 'MaxOrder', -1); %sym2
predictStep28 = liftingStep('Type', 'predict', 'Coefficients',0.4123, 'MaxOrder', 0); %sym3
predictStep29 = liftingStep('Type', 'predict', 'Coefficients',[-0.4922 -0.0285], 'MaxOrder', 1); %sym3
predictStep30 = liftingStep('Type', 'predict', 'Coefficients',0.3911, 'MaxOrder', 0); %sym4
predictStep31 = liftingStep('Type', 'predict', 'Coefficients',[-1.4195 0.1620], 'MaxOrder', 1); %sym4
predictStep32 = liftingStep('Type', 'predict', 'Coefficients',-1.0493, 'MaxOrder', 1); %sym4
predictStep33 = liftingStep('Type', 'predict', 'Coefficients',-0.9259, 'MaxOrder', 0); %sym5
predictStep34 = liftingStep('Type', 'predict', 'Coefficients',[-0.4293 -1.4521], 'MaxOrder', 1); %sym5
predictStep35 = liftingStep('Type', 'predict', 'Coefficients',[1.9589 0.7681], 'MaxOrder', 0); %sym5
predictStep36 = liftingStep('Type', 'predict', 'Coefficients',0.2266, 'MaxOrder', 0); %sym6
predictStep37 = liftingStep('Type', 'predict', 'Coefficients',[-0.5048 4.2552], 'MaxOrder', -1); %sym6
predictStep38 = liftingStep('Type', 'predict', 'Coefficients',[18.3890 -6.6245], 'MaxOrder', -3); %sym6
predictStep39 = liftingStep('Type', 'predict', 'Coefficients',5.5119, 'MaxOrder', -5); %sym6
predictStep40 = liftingStep('Type', 'predict', 'Coefficients',[-0.3389 7.1808], 'MaxOrder', 0); %sym7
predictStep41 = liftingStep('Type', 'predict', 'Coefficients',[29.6887 0.1339], 'MaxOrder', -2); %sym7
predictStep42 = liftingStep('Type', 'predict', 'Coefficients',[-7.4252 -2.3108], 'MaxOrder', -4); %sym7
predictStep43 = liftingStep('Type', 'predict', 'Coefficients',-1.1988, 'MaxOrder', -6); %sym7
predictStep44 = liftingStep('Type', 'predict', 'Coefficients',0.1603, 'MaxOrder', 0); %sym8
predictStep45 = liftingStep('Type', 'predict', 'Coefficients',[-0.4881 1.8079], 'MaxOrder', -1); %sym8
predictStep46 = liftingStep('Type', 'predict', 'Coefficients',[-0.5686 -0.2566], 'MaxOrder', -3); %sym8
predictStep47 = liftingStep('Type', 'predict', 'Coefficients',[0.5881 -0.3717], 'MaxOrder', -5); %sym8
predictStep48 = liftingStep('Type', 'predict', 'Coefficients',0.3531, 'MaxOrder', -7); %sym8
predictStep49 = liftingStep('Type', 'predict', 'Coefficients',4.6458, 'MaxOrder', 0); %coif1
predictStep50 = liftingStep('Type', 'predict', 'Coefficients',[7.4686 -0.6076], 'MaxOrder', -1); %coif1
predictStep51 = liftingStep('Type', 'predict', 'Coefficients',2.5303, 'MaxOrder', 0); %coif2
predictStep52 = liftingStep('Type', 'predict', 'Coefficients',[-3.1632 -15.2684], 'MaxOrder', -1); %coif2
predictStep53 = liftingStep('Type', 'predict', 'Coefficients',[63.9510 -13.5912], 'MaxOrder', -3); %coif2
predictStep54 = liftingStep('Type', 'predict', 'Coefficients',3.7930, 'MaxOrder', -5); %coif2
predictStep55 = liftingStep('Type', 'predict', 'Coefficients',[-0.3750 -1.1250], 'MaxOrder', 1); %bior3.1
predictStep56 = liftingStep('Type', 'predict', 'Coefficients',[-1.5861 -1.5861], 'MaxOrder', 1); %bior4.4
predictStep57 = liftingStep('Type', 'predict', 'Coefficients',[-0.8829 -0.8829], 'MaxOrder', 0); %bior4.4
predictStep58 = liftingStep('Type', 'predict', 'Coefficients',[4.9933 4.9933], 'MaxOrder', 1); %bior5.5
predictStep59 = liftingStep('Type', 'predict', 'Coefficients',[5.5858 5.5858], 'MaxOrder', 0); %bior5.5
predictStep60 = liftingStep('Type', 'predict', 'Coefficients',[0.2901 0.2901], 'MaxOrder', -2); %bior5.5
predictStep61 = liftingStep('Type', 'predict', 'Coefficients',[-0.9972 2.6590], 'MaxOrder', 1); %bior6.8
predictStep62 = liftingStep('Type', 'predict', 'Coefficients',[3.2687 -3.8778], 'MaxOrder', -1); %bior6.8
predictStep63 = liftingStep('Type', 'predict', 'Coefficients',[-2.9418 0.5486], 'MaxOrder', -3); %bior6.8
updateStep1 = liftingStep('Type', 'update', 'Coefficients', [1/2], 'MaxOrder', 0);
updateStep2 = liftingStep('Type', 'update', 'Coefficients', [1/4 1/4], 'MaxOrder', 0);
updateStep3 = liftingStep('Type', 'update', 'Coefficients', [-1/3], 'MaxOrder', -1); %bior3.1
updateStep4 = liftingStep('Type', 'update', 'Coefficients', [4/9], 'MaxOrder', 0); %bior3.1
updateStep5 = liftingStep('Type', 'update', 'Coefficients',[-1/12 4/9 1/12], 'MaxOrder', 1);
updateStep6 = liftingStep('Type', 'update', 'Coefficients', [-0.0670 0.4330], 'MaxOrder', 1);
updateStep7 = liftingStep('Type', 'update', 'Coefficients', [-0.0793 0.3524], 'MaxOrder', 1);
updateStep8 = liftingStep('Type', 'update', 'Coefficients', 0.0198, 'MaxOrder', 2);
updateStep9 = liftingStep('Type', 'update', 'Coefficients', [-1.1171 -0.3001], 'MaxOrder', 0);
updateStep10 = liftingStep('Type', 'update', 'Coefficients', [2.1318 0.6364], 'MaxOrder', 0);
updateStep11 = liftingStep('Type', 'update', 'Coefficients', [0.9941 0.2477], 'MaxOrder', 0);
updateStep12 = liftingStep('Type', 'update', 'Coefficients', [0.2247 -0.7169], 'MaxOrder', 2);
updateStep13 = liftingStep('Type', 'update', 'Coefficients', -0.0358, 'MaxOrder', 3);
updateStep14 = liftingStep('Type', 'update', 'Coefficients', [-0.0633 0.2146], 'MaxOrder', 1);
updateStep15 = liftingStep('Type', 'update', 'Coefficients', [-0.0237 0.0574], 'MaxOrder', 3);
updateStep16 = liftingStep('Type', 'update', 'Coefficients', [-9.9117e-04 0.0072], 'MaxOrder', 5);
updateStep17 = liftingStep('Type', 'update', 'Coefficients', 5.0935, 'MaxOrder', 0);
updateStep18 = liftingStep('Type', 'update', 'Coefficients', [5.9592 -12.2854], 'MaxOrder', 2);
updateStep19 = liftingStep('Type', 'update', 'Coefficients', [0.0508 -0.4142], 'MaxOrder', 6);
updateStep20 = liftingStep('Type', 'update', 'Coefficients', [1.5604 -3.9707], 'MaxOrder', 4);
updateStep21 = liftingStep('Type', 'update', 'Coefficients', [-0.0523 0.1688], 'MaxOrder', 1);
updateStep22 = liftingStep('Type', 'update', 'Coefficients', [-0.0324 0.0609], 'MaxOrder', 3);
updateStep23 = liftingStep('Type', 'update', 'Coefficients', [0.9453 0.2420], 'MaxOrder', 5);
updateStep24 = liftingStep('Type', 'update', 'Coefficients', [-0.9526 -0.2241], 'MaxOrder', 5);
updateStep25 = liftingStep('Type', 'update', 'Coefficients', [-0.0670 0.4330], 'MaxOrder', 1);
updateStep26 = liftingStep('Type', 'update', 'Coefficients', [-0.3524 1.5651], 'MaxOrder', 0);
updateStep27 = liftingStep('Type', 'update', 'Coefficients', [-0.9526 -0.2241], 'MaxOrder', 5);
updateStep28 = liftingStep('Type', 'update', 'Coefficients', 0.3896, 'MaxOrder', 0);
updateStep29 = liftingStep('Type', 'update', 'Coefficients', [-0.1244 -0.3392], 'MaxOrder', 1);
updateStep30 = liftingStep('Type', 'update', 'Coefficients', [0.4313 0.1460], 'MaxOrder', 0);
updateStep31 = liftingStep('Type', 'update', 'Coefficients', [0.4985 0.1319], 'MaxOrder', 0);
updateStep32 = liftingStep('Type', 'update', 'Coefficients', [-0.0948 0.2804], 'MaxOrder', 1);
updateStep33 = liftingStep('Type', 'update', 'Coefficients', [1.2671 -0.2155], 'MaxOrder', 1);
updateStep34 = liftingStep('Type', 'update', 'Coefficients', [-0.0447 -0.2332], 'MaxOrder', 3);
updateStep35 = liftingStep('Type', 'update', 'Coefficients', [-0.1444 0.0568], 'MaxOrder', 5);
updateStep36 = liftingStep('Type', 'update', 'Coefficients', 0.3906, 'MaxOrder', 0);
updateStep37 = liftingStep('Type', 'update', 'Coefficients', [-0.0139 -0.1373], 'MaxOrder', 2);
updateStep38 = liftingStep('Type', 'update', 'Coefficients', [0.1285 -1.0688e-04], 'MaxOrder', 4);
updateStep39 = liftingStep('Type', 'update', 'Coefficients', [0.0533 0.2886], 'MaxOrder', 6);
updateStep40 = liftingStep('Type', 'update', 'Coefficients', [0.7103 -0.1563], 'MaxOrder', 1);
updateStep41 = liftingStep('Type', 'update', 'Coefficients', [1.7399 -0.4863], 'MaxOrder', 3);
updateStep42 = liftingStep('Type', 'update', 'Coefficients', [-0.8355 3.7023], 'MaxOrder', 5);
updateStep43 = liftingStep('Type', 'update', 'Coefficients', [-2.1581 0.7492], 'MaxOrder', 7);
updateStep44 = liftingStep('Type', 'update', 'Coefficients', [-0.1172 -0.2057], 'MaxOrder', 1);
updateStep45 = liftingStep('Type', 'update', 'Coefficients', 0.0729, 'MaxOrder', 2);
updateStep46 = liftingStep('Type', 'update', 'Coefficients', [0.2401 -0.3418], 'MaxOrder', 1);
updateStep47 = liftingStep('Type', 'update', 'Coefficients', [-0.0057 0.0646], 'MaxOrder', 3);
updateStep48 = liftingStep('Type', 'update', 'Coefficients', [-5.0873e-04 0.0019], 'MaxOrder', 5);
updateStep49 = liftingStep('Type', 'update', 'Coefficients', [-0.0625 0.5000 0.0625], 'MaxOrder', 1);
updateStep50 = liftingStep('Type', 'update', 'Coefficients', [0.0117 -0.0859 0.5000 0.0859 -0.0117], 'MaxOrder', 2);
updateStep51 = liftingStep('Type', 'update', 'Coefficients', [-0.0469 0.2969 0.2969 -0.0469], 'MaxOrder', 1);
updateStep52 = liftingStep('Type', 'update', 'Coefficients', [0.0098 -0.0762 0.3164 0.3164 -0.0762 0.0098], 'MaxOrder', 2);
updateStep53 = liftingStep('Type', 'update', 'Coefficients', [-0.0021 0.0204 -0.0954 0.3271 0.3271 -0.0954 0.0204 -0.0021], 'MaxOrder', 3);
updateStep54 = liftingStep('Type', 'update', 'Coefficients', [0.0174 -0.1181 0.4444 0.1181 -0.0174], 'MaxOrder', 2);
updateStep55 = liftingStep('Type', 'update', 'Coefficients', [-0.0038 0.0326 -0.1370 0.4444 0.1370 -0.0326 0.0038], 'MaxOrder', 3);
updateStep56 = liftingStep('Type', 'update', 'Coefficients', [8.5449e-04 -0.0089 0.0445 -0.1490 0.4444 0.1490 -0.0445 0.0089 -8.5449e-04], 'MaxOrder', 4);
updateStep57 = liftingStep('Type', 'update', 'Coefficients', [1.0796 -0.0530], 'MaxOrder', 0);
updateStep58 = liftingStep('Type', 'update', 'Coefficients', [0.4435 1.5761], 'MaxOrder', 2);
updateStep59 = liftingStep('Type', 'update', 'Coefficients', [-0.1834 -0.0044], 'MaxOrder', 0);
updateStep60 = liftingStep('Type', 'update', 'Coefficients', -3.4472, 'MaxOrder', 3);
updateStep61 = liftingStep('Type', 'update', 'Coefficients', [-0.2735 -0.2735], 'MaxOrder', 1);
updateStep62 = liftingStep('Type', 'update', 'Coefficients', [0.2865 0.2865], 'MaxOrder', 3);
updateStep63 = liftingStep('Type', 'update', 'Coefficients', [-0.0998 0.3438 0.3438 -0.0998], 'MaxOrder', 5);


lScheme = liftingScheme("Wavelet", "db1");
lScheme2 = liftingScheme("Wavelet", "db2");
lScheme3 = liftingScheme("Wavelet", "sym3");


[lod2,hid2,lor2,hir2] = ls2filt(lScheme);
bswfun(lod2,hid2,lor2,hir2,'plot');
title('db1');

[lod2_,hid2_,lor2_,hir2_] = ls2filt(lScheme2);
bswfun(lod2_,hid2_,lor2_,hir2_,'plot');
title('db2');

[lod_2,hid_2,lor_2,hir_2] = ls2filt(lScheme3);
bswfun(lod_2,hid_2,lor_2,hir_2,'plot');
title('db3');
%}

figure(3);
[LoD,HiD,LoR,HiR] = wfilters('db2'); 
subplot(2,2,1)
stem(LoD)
title("Decomposition Lowpass Filter")
subplot(2,2,2)
stem(HiD)
title("Decomposition Highpass Filter")
subplot(2,2,3)
stem(LoR)
title("Reconstruction Lowpass Filter")
subplot(2,2,4)
stem(HiR)
title("Reconstruction Highpass Filter")

figure(4);
[LoD1,HiD1,LoR1,HiR1] = wfilters('sym2'); 
subplot(2,2,1)
stem(LoD1)
title("Decomposition Lowpass Filter")
subplot(2,2,2)
stem(HiD1)
title("Decomposition Highpass Filter")
subplot(2,2,3)
stem(LoR1)
title("Reconstruction Lowpass Filter")
subplot(2,2,4)
stem(HiR1)
title("Reconstruction Highpass Filter")
