lvl=7;

%imagenes = ["CT_Torax_1.dcm", "CT_Prostata_1.dcm", "CT_Pediatrica_1.dcm", "CT_Cerebral_1.dcm", "CT_Cerebral_2.dcm", "CT_Abdomen_1.dcm", "CT_Abdomen_2.dcm", "CT_Abdomen_3.dcm","CT_Abdomen_4.dcm","CT_Abdomen_5.dcm"];
%imagenes = ["MRI_Seno_1.dcm", "MRI_Rinon_1.dcm", "MRI_Pelvis_1.dcm", "MRI_Pelvis_2.dcm", "MRI_Pancreas_1.dcm", "MRI_Cerebral_1.dcm", "MRI_Cerebral_2.dcm", "MRI_Cerebral_3.dcm","MRI_Abdomen_1.dcm","MRI_Abdomen_2.dcm"];
imagenes = ["US_ECHO_1.dcm", "US_ECHO_2.dcm", "US_ECHO_3.dcm", "US_ECHO_4.dcm", "US_ECHO_5.dcm", "US_ECHO_6.dcm", "US_ECHO_7.dcm", "US_ECHO_8.dcm","US_ECHO_9.dcm","US_ECHO_10.dcm"];

lCustom1 = liftingScheme('wavelet', 'lazy');
lCustom1.NormalizationFactors = [2.121320343559643 0.471404520791032];
lCustom2 = liftingScheme('wavelet', 'lazy');
lCustom2.NormalizationFactors = [2.121320343559643 0.471404520791032];

updateStep1 = liftingStep('Type', 'update', 'Coefficients', [1/2], 'MaxOrder', 0);
predictStep3 = liftingStep('Type', 'predict', 'Coefficients',[-0.375 -1.125], 'MaxOrder', 1);
updateStep44 = liftingStep('Type', 'update', 'Coefficients', [-0.1172 -0.2057], 'MaxOrder', 1);
updateStep34 = liftingStep('Type', 'update', 'Coefficients', [-0.0447 -0.2332], 'MaxOrder', 3);
updateStep5 = liftingStep('Type', 'update', 'Coefficients',[-1/12 4/9 1/12], 'MaxOrder', 1);

lCustom1 = addlift(lCustom1, updateStep44);
lCustom1 = addlift(lCustom1, predictStep3);
lCustom1 = addlift(lCustom1, updateStep1);  

lCustom2 = addlift(lCustom2, updateStep34);
lCustom2 = addlift(lCustom2, predictStep3);
lCustom2 = addlift(lCustom2, updateStep5);

EsquemaLifting = [lCustom1, lCustom2];

archivo_mse = ["mse_custom1_cuantizador_US.xls","mse_custom2_cuantizador_US.xls"];
archivo_psnr = ["psnr_custom1_cuantizador_US.xls", "psnr_custom2_cuantizador_US.xls"];
%archivo_ratio = ["Compression_ratio_custom1_cuantizador_CT.xls","Compression_ratio_custom2_cuantizador_CT.xls"];
%archivo_ACL = ["ACL_custom1_cuantizador_CT.xls","ACL_custom2_cuantizador_CT.xls"];

mean_mse = cell(1,2);
mean_psnr = cell(1,2);
%mean_ratio = cell(1,2);
%mean_ACL = cell(1,2);

for j=1:2

    %ls = liftingScheme("Wavelet", wavelet_madre{1,j});
    ls = EsquemaLifting(1,j);

for i=1:10

image = dicomread(imagenes{1,i},'Frames','all');
image = image(:,:,1,1);

%Para pruebas sobre imagenes de Ultra Sonido (US)
%image = image(:,:,1,1); %Se selecciona el canal 1 (R) y 1 fotograma del estudio de US, para CT o MR se comenta esta linea

for k=1:lvl
    
    %[eficiencia(i,k), compression_ratio(i,k), ACL(i,k)] = Prueba_3_Huffman(k, image, ls);
    [mse(i,k), psnr(i,k)] = Prueba_lifting_update_first_cuantificador(k, image, ls);
end
display(i);
end

%archivo_eficiencia = 'eficiencia.xlsx'; % Nombre del archivo xlsx
writematrix(mse, archivo_mse{1,j}); % Guardar la matriz en el archivo xlsx
writematrix(psnr, archivo_psnr{1,j});
%archivo_ratio = 'compression_ratio.xlsx'; % Nombre del archivo xlsx
%writematrix(compression_ratio, archivo_ratio{1,j}); % Guardar la matriz en el archivo xlsx
%archivo_ACL = 'Acl.xlsx'; % Nombre del archivo xlsx
%writematrix(ACL, archivo_ACL{1,j}); % Guardar la matriz en el archivo xlsx

mean_mse{1,j}  = mean(mse);
mean_psnr{1,j} = mean(psnr);
%mean_ratio{1,j}  = mean(compression_ratio);
%mean_ACL{1,j}  = mean(ACL);
display(j);
end

figure(1);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_mse{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_mse{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
hold off
xlabel('Niveles de descomposición');
ylabel('Error cuadrático medio (MSE)');
legend('Esquema Propuesto 1', 'Esquema Propuesto 2');
title('Error Cuadrático Medio (MSE) vs Niveles de Descomposición - US - Cuantificador - Esquema Lifting Personalizado "Update First"');

figure(2);
set(gcf,'color','w');
grid on
hold on
plot(1:lvl, mean_psnr{:,1},'-o', 'color', '#1f77b4', 'LineWidth', 1.1);
plot(1:lvl, mean_psnr{:,2},'-+', 'color', '#ff7f0e', 'LineWidth', 1.1);
hold off
xlabel('Niveles de descomposición');
ylabel('Relación máxima de señal a ruido (PSNR)');
legend('Esquema Propuesto 1', 'Esquema Propuesto 2');
title('Relación Máxima de Señal a Ruido (PSNR) vs Niveles de Descomposición - US - Cuantificador - Esquema Lifting Personalizado "Update First"');